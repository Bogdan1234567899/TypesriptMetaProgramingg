import os

class Config:
    TELEGRAM_TOKEN = os.getenv("TELEGRAM_TOKEN", "8561396736:AAE53G6rmoBtMUg5Nesl_bXXPnAhqS7LBNI").strip()
    DB_PATH = os.getenv("DB_PATH", "finance_bot.sqlite3").strip()
